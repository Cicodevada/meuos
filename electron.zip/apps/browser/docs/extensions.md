# Extensions

Wexond has partial support for Chrome extensions (see [#110](https://github.com/wexond/desktop/issues/110)).

# Installing an extension

To install an extension, you will need to extract the `crx` file of the extension and put the extracted folder to `extensions` directory.

The `extensions` directory paths:
- On Linux and macOS: `~/.wexond/extensions`
- On Windows: `%USERPROFILE%/.wexond/extensions`
