# Documentation

## Table of contents

1. [Keyboard shortcuts](keyboard-shortcuts.md)
2. [Extensions](extensions.md)
