import { configureRenderer } from '~/common/renderer-config';
configureRenderer();
