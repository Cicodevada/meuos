export const FONT_ROBOTO_REGULAR = require('~/renderer/resources/fonts/roboto-regular.woff2');
export const FONT_ROBOTO_MEDIUM = require('~/renderer/resources/fonts/roboto-medium.woff2');
export const FONT_ROBOTO_LIGHT = require('~/renderer/resources/fonts/roboto-light.woff2');
