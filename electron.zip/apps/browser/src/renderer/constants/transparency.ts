export const transparency = {
  text: {
    high: 0.87,
    medium: 0.6,
    disabled: 0.38,
  },
  icons: {
    active: 0.87,
    inactive: 0.6,
    disabled: 0.38,
  },
  dividers: 0.12,
};
