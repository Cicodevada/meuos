export * from './settings';

export const EXTENSIONS_PROTOCOL = 'chrome-extension';
