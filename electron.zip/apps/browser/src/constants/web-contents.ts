export const ZOOM_FACTOR_INCREMENT = 0.2;
export const ZOOM_FACTOR_MAX = 5;
export const ZOOM_FACTOR_MIN = 0.2;
