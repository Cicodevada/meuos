export interface IURLSegment {
  value: string;
  grayOut: boolean;
}
