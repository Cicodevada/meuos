declare module '*.svg';
declare module '*.png';
declare module '*.woff2';
