const { app, BrowserWindow } = require('electron')
const path = require('path');

const createWindow = () => {
  const win = new BrowserWindow({
    //fullscreen: true, // Janela em tela cheia
    //skipTaskbar: true, // Oculta da barra de tarefas
    //frame: false, // Remove as bordas e barra da janela
    //alwaysOnBottom: true, // Opção para deixar atrás (veja as notas abaixo)
    webPreferences: {
      webviewTag: true,
      nodeIntegration: false,  // Desabilitar nodeIntegration por segurança
      contextIsolation: true, // Isolamento do contexto para segurança
    }
  })

  win.loadFile('index.html');
  win.setAlwaysOnTop(false);
  //win.setKiosk(true);
}

app.whenReady().then(() => {
  createWindow()
})